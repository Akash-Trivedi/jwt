import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import slbn.*;

public class SlrySlip extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res)
	{
		int empNo=0,bs=0,year=0,da=0,hra=0,pf=0,lwp=0,gross=0,net=0,dlwp=0;
		String empName="",dept="",month="",address="";

		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/salary_slip","root","");
			
			Statement stmt1=conn.createStatement();
			empNo=Integer.parseInt(req.getParameter("empNo"));
		
			ResultSet rs1=stmt1.executeQuery("select * from emp_master where empNo="+empNo);
		
			if(rs1.next()==false)
				address="/WEB-INF/results/notFound.jsp";
			else
			{
				Statement stmt3=conn.createStatement();
				ResultSet rs2=stmt3.executeQuery("select * from emp_salary where empNo="+empNo);
				
				if(rs2.next()==false)
				{
					empName=rs1.getString("empName");
					month=req.getParameter("month");
					bs=rs1.getInt("salary");
					dept=rs1.getString("department");
					dlwp=Integer.parseInt(req.getParameter("dlwp"));				
			
					year=Integer.parseInt(req.getParameter("year"));
					da=(bs/10)*2;
					hra=(bs/10)*1;
					pf=1800;
					lwp=(bs/30)*dlwp;
					gross=bs+da+hra;
					net=gross-pf-lwp;
			
					Statement stmt2=conn.createStatement();
					String query="insert into emp_salary values ("+empNo+" ,' "+month+" ', "+year+","+bs+","+da+","+hra+","+gross+","+pf+","+lwp+","+net+");" ;
					System.out.println(query);
					stmt2.executeUpdate(query);
				
					SalaryBean sb=new SalaryBean(empNo,empName,month,dept,year,bs,da,hra,pf,lwp,gross,net);	
					req.setAttribute("sb",sb);
			
					address="/WEB-INF/results/found.jsp";
				}
				else
				{
					empName=rs1.getString("empName");
					dept=rs1.getString("department");
					month=rs2.getString("month");
					year=rs2.getInt("year");		
					bs=rs2.getInt("basic");
					da=rs2.getInt("da");
					hra=rs2.getInt("hra");
					pf=rs2.getInt("pf");
					lwp=rs2.getInt("lwp");
					gross=rs2.getInt("gross");
					net=rs2.getInt("net");
			
					SalaryBean sb=new SalaryBean(empNo,empName,month,dept,year,bs,da,hra,pf,lwp,gross,net);	
					req.setAttribute("sb",sb);
			
					address="/WEB-INF/results/exist.jsp";
			
				}
			
				RequestDispatcher dispatch=req.getRequestDispatcher(address);
				dispatch.forward(req,res);
			}
		}
		catch(Exception e)
		{	System.out.println(e);	}
	}
}