package slbn;

public class SBean
{
	private int empNo,bs,year,da,hra,gross,pf,lwp,net;
	private String empName,dept,month,type;
	
	public SBean(int empNo,String empName,String month,String dept,int year,int bs,int da,int hra,int pf,int lwp,int gross,int net)
	{
		this.empNo=empNo;
		this.empName=empName;
		this.month=month;
		this.dept=dept;
		this.year=year;
		this.bs=bs;
		this.da=da;
		this.hra=hra;
		this.pf=pf;
		this.lwp=lwp;
		this.gross=gross;
		this.net=net;
	}

	public int getEmpNo()
	{
		return(empNo);
	}

	public String getEmpName()
	{
		return(empName);
	}
	
	public String getMonth()
	{
		return(month);
	}
	public String getDept()
	{
		return(dept);
	}
	public int getYear()
	{
		return(year);
	}	
	public int getBs()
	{
		return(bs);
	}
	public int getDa()
	{
		return(da);
	}
	public int getHra()
	{
		return(hra);
	}	
	public int getPf()
	{
		return(pf);
	}
	public int getLwp()
	{
		return(lwp);
	}
	public int getGross()
	{
		return(gross);
	}
	public int getNet()
	{
		return(net);
	}
			
}