-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 11, 2021 at 09:44 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `salary_slip`
--

-- --------------------------------------------------------

--
-- Table structure for table `emp_master`
--

CREATE TABLE `emp_master` (
  `empNo` int(3) NOT NULL,
  `empName` varchar(20) NOT NULL,
  `salary` int(5) NOT NULL,
  `department` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `emp_master`
--

INSERT INTO `emp_master` (`empNo`, `empName`, `salary`, `department`) VALUES
(1, 'Bhavik', 25000, 'IT'),
(2, 'Derlin', 15000, 'CA'),
(3, 'Nipesh', 30000, 'MCA'),
(4, 'Siddharth', 20000, 'BCOM'),
(5, 'Akash', 40000, 'BBA');

-- --------------------------------------------------------

--
-- Table structure for table `emp_salary`
--

CREATE TABLE `emp_salary` (
  `empNo` int(3) NOT NULL,
  `month` varchar(10) NOT NULL,
  `year` int(4) NOT NULL,
  `basic` int(7) NOT NULL,
  `da` int(5) NOT NULL,
  `hra` int(5) NOT NULL,
  `gross` int(7) NOT NULL,
  `pf` int(5) NOT NULL,
  `lwp` int(3) NOT NULL,
  `net` int(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `emp_salary`
--

INSERT INTO `emp_salary` (`empNo`, `month`, `year`, `basic`, `da`, `hra`, `gross`, `pf`, `lwp`, `net`) VALUES
(1, ' March ', 2020, 25000, 5000, 2500, 32500, 1800, 4165, 26535),
(2, ' December ', 2021, 15000, 3000, 1500, 19500, 1800, 1500, 16200);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
